"""Check the extracted release before recomputing its generated outputs."""
from pathlib import Path
import json,hashlib

def main():
    root=Path(__file__).resolve().parent
    manifest=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
    failures=[]
    for name,digest in manifest['files'].items():
        p=root/name
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest: failures.append(name)
    if failures: raise SystemExit('Missing or changed release files: '+', '.join(failures))
    print(f"SHA-256 verified: {len(manifest['files'])} release files.")

if __name__=='__main__': main()
