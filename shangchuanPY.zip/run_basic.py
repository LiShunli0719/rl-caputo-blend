"""Reproduce all synthetic experiments using Python 3 and NumPy only.

No measured data are used. Tables and vector PGFPlots figures are generated from
the saved CSV files; this script never edits or compiles the manuscript.
"""
from pathlib import Path
from functools import lru_cache
import csv, json, math, hashlib, platform, time
import numpy as np
from numpy.polynomial.legendre import leggauss

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'results'; FIG=ROOT/'figures'
DATA.mkdir(exist_ok=True); FIG.mkdir(exist_ok=True)
SEED=20261117
ALPHAS=(.3,.6,.85)
NS=(256,512,1024,2048,4096)
A0=1.3; A1=.7; T=4.; DELTA=.25
KTRUE=.65; ANCHOR=.8; SIGMA=.005; REPLICATES=400
checks=[]; outputs=[]

def check(name,value,tol):
    value=float(value)
    checks.append(dict(name=name,value=value,tolerance=tol,passed=value<=tol))
    if value>tol: print('CHECK FAILED:',name,value,'>',tol,flush=True)

def save_csv(name,columns,rows):
    p=DATA/name
    with p.open('w',newline='',encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(columns); w.writerows(rows)
    outputs.append(p)

@lru_cache(None)
def gauss(n):
    x,w=leggauss(n)
    return (x+1)/2,w/2

def ml_relax(alpha,lam,t,order=512):
    """E_alpha(-lam*t**alpha), from its positive spectral density.

    The exact inverse-CDF substitution u=lam**(1/alpha)*
    [sin(pi*alpha*v)/sin(pi*alpha*(1-v))]**(1/alpha) maps K(u)du to dv.
    This integral reference shares no GL weights with the time integrator.
    """
    t=np.asarray(t,dtype=float)
    v,w=gauss(order)
    u=lam**(1/alpha)*(np.sin(np.pi*alpha*v)/np.sin(np.pi*alpha*(1-v)))**(1/alpha)
    out=np.empty(t.shape)
    flat=out.reshape(-1); tt=t.reshape(-1)
    for start in range(0,len(tt),512):
        flat[start:start+512]=np.exp(-np.outer(tt[start:start+512],u))@w
    return out

def weights(alpha,n):
    w=np.ones(n+1)
    for j in range(1,n+1): w[j]=w[j-1]*(1-(alpha+1)/j)
    return w

def solve(alpha,n,kappa=0.,anchor=0.,initial=0.,input_values=None):
    h=T/n; t=h*np.arange(n+1); w=weights(alpha,n)
    c=h**(-alpha)*np.cumsum(w)
    x=np.ones(n+1) if input_values is None else input_values
    y=np.zeros(n+1); y[0]=initial
    diagonal=A0+A1*h**(-alpha)
    for i in range(1,n+1):
        y[i]=(x[i]+A1*kappa*anchor*c[i]
              -A1*h**(-alpha)*np.dot(w[1:i+1],y[i-1::-1]))/diagonal
    return t,y

def solve_parameters(alpha,a0,a1,n,kappa=0.,anchor=0.):
    h=T/n; t=h*np.arange(n+1); w=weights(alpha,n)
    c=h**(-alpha)*np.cumsum(w)
    y=np.zeros(n+1); y[0]=kappa*anchor
    for i in range(1,n+1):
        y[i]=(1.+a1*kappa*anchor*c[i]
              -a1*h**(-alpha)*np.dot(w[1:i+1],y[i-1::-1]))/(a0+a1*h**(-alpha))
    return t,y

def fractional_power_integral(alpha,beta,p,t,dx=.025):
    """I^(1-alpha) (C D^beta t^p)' by independent logistic quadrature."""
    length=45/min(p-beta,1-alpha)
    count=int(math.ceil(2*length/dx))
    x=np.linspace(-length,length,count+1)
    lv=-np.logaddexp(0.,-x); l1v=-np.logaddexp(0.,x)
    f=np.exp((p-beta)*lv+(1-alpha)*l1v)
    integral=(f[0]/2+f[-1]/2+sum(f[1:-1]))*(2*length/count)
    return math.gamma(p+1)*t**(p-alpha-beta)*integral/(math.gamma(p-beta)*math.gamma(1-alpha))

def harmonic(alpha,t,order=24,first_order=192):
    # Integral endpoint is removed analytically; remaining oscillations use panels <= pi/2.
    v,w=gauss(first_order)
    first=np.dot(w,np.exp(-1j*v**(1/(1-alpha))))/(1-alpha)
    if t<=1: raise ValueError('harmonic grid must start above one')
    panels=int(math.ceil((t-1)/(math.pi/2)))
    edges=np.linspace(1,t,panels+1)
    z,ww=gauss(order)
    u=edges[:-1,None]+np.diff(edges)[:,None]*z
    rest=np.sum(np.diff(edges)[:,None]*ww*(u**(-alpha))*np.exp(-1j*u))
    return 1j*np.exp(1j*t)*(first+rest)/math.gamma(1-alpha)

def frequency_model(theta,omega):
    a0,a1,alpha=theta
    return 1/(a0+a1*(1j*omega)**alpha)

def fit_frequency(obs,omega):
    """Damped analytic Gauss--Newton; three fixed starts, no knowledge of truth."""
    scale=1/abs(obs)
    def objective(p):
        theta=(math.exp(p[0]),math.exp(p[1]),p[2])
        residual=(frequency_model(theta,omega)-obs)*scale
        return float(np.vdot(residual,residual).real),residual,theta
    records=[]
    for start in [(1.,1.,.35),(.6,1.4,.7),(2.,.4,.85)]:
        p=np.array([math.log(start[0]),math.log(start[1]),start[2]])
        for it in range(100):
            loss,res,theta=objective(p); a0,a1,alpha=theta
            H=frequency_model(theta,omega); z=(1j*omega)**alpha
            J=np.column_stack([-a0*H*H,-a1*z*H*H,-a1*z*np.log(1j*omega)*H*H])*scale[:,None]
            JJ=np.vstack([J.real,J.imag]); rr=np.r_[res.real,res.imag]
            step=np.linalg.lstsq(JJ,-rr,rcond=None)[0]
            accepted=False
            for j in range(25):
                q=p+step*(.5**j)
                if not (.05<=q[2]<=.95 and np.max(abs(q[:2]))<8): continue
                new=objective(q)[0]
                if new<loss:
                    p=q; accepted=True; break
            if not accepted or np.linalg.norm(step*(.5**j))<1e-11: break
        loss,res,theta=objective(p)
        records.append(dict(theta=list(theta),loss=loss,iterations=it+1))
    best=min(records,key=lambda r:r['loss'])
    return np.array(best['theta']),records

def rmse(y,z): return float(np.sqrt(np.mean((y-z)**2)))
def order(old,new): return math.log(old/new,2) if old is not None else None
def sci(x):
    if x is None: return '--'
    if x==0: return '$0$'
    a,e=f'{x:.2e}'.split('e')
    return rf'${a}\times10^{{{int(e)}}}$'
def dec(x): return '--' if x is None else f'{x:.3f}'

tables=[]
def table(label,caption,heads,rows,align=None):
    from table_format import current_table
    caption,heads,rows=current_table(label,caption,heads,rows)
    align=align or 'r'*len(heads)
    lines=[r'\begin{table}[htbp]',r'\centering',r'\small',r'\setlength{\tabcolsep}{4pt}',
           rf'\caption{{{caption}}}\label{{{label}}}',rf'\begin{{tabular}}{{{align}}}',r'\toprule',
           ' & '.join(heads)+r' \\',r'\midrule']
    lines+=[' & '.join(map(str,row))+r' \\' for row in rows]
    lines += [r'\bottomrule',r'\end{tabular}',r'\end{table}','']
    tables.extend(lines)

def figure(name,csvname,x,curves,xlabel,ylabel,caption,label,logx=False,logy=False,extra=''):
    # color/line conventions are shared with the manuscript's analytical figure.
    options=[r'journalaxis',rf'xlabel={{{xlabel}}}',rf'ylabel={{{ylabel}}}']
    if logx: options+=['xmode=log']
    if logy: options+=['ymode=log']
    if extra: options.append(extra)
    tex=[r'\begin{figure}[htbp]',r'\centering',r'\begin{tikzpicture}',
         '\\begin{axis}[\n'+',\n'.join(options)+'\n]']
    for column,legend,style in curves:
        tex += [rf'\addplot+[{style}] table[x={x},y={column},col sep=comma]{{results/{csvname}}};',
                rf'\addlegendentry{{{legend}}}']
    tex += [r'\end{axis}',r'\end{tikzpicture}',rf'\caption{{{caption}}}\label{{{label}}}',r'\end{figure}']
    path=FIG/(name+'.tex'); path.write_text('\n'.join(tex)+'\n',encoding='utf-8'); outputs.append(path)

start=time.perf_counter()
print('1/6: independent fractional integral checks',flush=True)
integral_rows=[]
for alpha,beta in [(.3,.4),(.4,.6),(.6,.7),(.8,.6),(.9,.8)]:
    gamma=alpha+beta; err_defect=0.; err_composition=0.; refdiff=0.
    for t in (.1,.5,1.,2.):
        num=sum(fractional_power_integral(alpha,beta,p,t) for p in (1,2))
        if gamma>1:
            single=2*t**(2-gamma)/math.gamma(3-gamma)
            defect=t**(1-gamma)/math.gamma(2-gamma)
        else:
            single=sum(math.gamma(p+1)*t**(p-gamma)/math.gamma(p+1-gamma) for p in (1,2)); defect=0.
        err_defect=max(err_defect,abs(num-single-defect)/max(1.,abs(single),abs(defect)))
        target=2*t**(2-gamma)/math.gamma(3-gamma)
        comp=fractional_power_integral(alpha,beta,2,t)
        err_composition=max(err_composition,abs(comp-target)/max(1.,abs(target)))
        fine=sum(fractional_power_integral(alpha,beta,p,t,dx=.0125) for p in (1,2))
        refdiff=max(refdiff,abs(fine-num)/max(1.,abs(fine)))
    check(f'composition_defect_{alpha}_{beta}',err_defect,1e-11)
    check(f'conditional_composition_{alpha}_{beta}',err_composition,1e-11)
    integral_rows.append((alpha,beta,gamma,err_defect,err_composition,refdiff))
save_csv('composition.csv',['alpha','beta','gamma','defect_relative_error','composition_relative_error','quadrature_refinement'],integral_rows)
table('tab:composition',r'Independent integral verification on $t\in\{0.1,0.5,1,2\}$. The defect test uses $f=t+t^2$; conditional composition uses $f=t^2$. Errors are normalized by the maximum of one and the magnitudes of the compared terms.',
      [r'$\alpha$',r'$\beta$',r'$\gamma$',r'Defect error',r'Composition error'],
      [[dec(a),dec(b),dec(g),sci(e),sci(c)] for a,b,g,e,c,q in integral_rows])

print('2/6: full-history GL convergence and endpoints',flush=True)
conv=[]; endpoints=[]; counter=[]; plot_conv=[]
stability_rows=[]
for alpha in ALPHAS:
    prev=[None]*3
    for n in NS:
        h=T/n; t=h*np.arange(n+1)
        x=A1*2*t**(2-alpha)/math.gamma(3-alpha)+A0*t*t
        _,smooth=solve(alpha,n,input_values=x)
        _,step=solve(alpha,n)
        relax=ml_relax(alpha,A0/A1,t,512)
        reference=(1-relax)/A0
        errors=[float(np.max(abs(smooth-t*t))),float(np.max(abs(step-reference))),float(np.max(abs(step[t>=DELTA]-reference[t>=DELTA])))]
        rates=[order(o,e) for o,e in zip(prev,errors)]
        conv.append(dict(alpha=alpha,n=n,h=h,smooth_error=errors[0],smooth_rate=rates[0],step_error=errors[1],step_rate=rates[1],window_error=errors[2],window_rate=rates[2]))
        prev=errors
        if n==NS[-1]:
            ref_fine=ml_relax(alpha,A0/A1,t,1024)
            check(f'ML_reference_refinement_alpha_{alpha}',np.max(abs(ref_fine-relax)),2e-9)
            save_csv(f'time_step_a{alpha:g}.csv',['t','smooth_GL','smooth_exact','step_GL','step_reference'],zip(t,smooth,t*t,step,reference))
    n=NS[-1]; h=T/n; t=h*np.arange(n+1); w=weights(alpha,n); S=np.cumsum(w); c=S*h**(-alpha)
    f=1+t*t; gl=np.convolve(w,f)[:n+1]*h**(-alpha)
    cap=np.convolve(w,f-f[0])[:n+1]*h**(-alpha)
    endpoint_error=float(np.max(abs(gl-c-cap)))
    gamma_c=np.exp(np.array([math.lgamma(j+1-alpha)-math.lgamma(1-alpha)-math.lgamma(j+1) for j in range(n+1)]))*h**(-alpha)
    gamma_error=float(np.max(abs(c-gamma_c))/max(abs(c)))
    check(f'GL_endpoint_identity_{alpha}',endpoint_error,2e-10)
    check(f'GL_constant_gamma_{alpha}',gamma_error,2e-11)
    mask=t>=DELTA
    exact_const=t[mask]**(-alpha)/math.gamma(1-alpha)
    const_error=float(np.max(abs(c[mask]-exact_const)))
    # Counterexample: inner signal is exactly g=1 with its actual right trace.
    for k in (0.,.5,1.):
        ratio=(1-k)*c[-1]/(T**(-alpha)/math.gamma(1-alpha))
        counter.append((alpha,k,ratio,1-k))
    endpoints.append((alpha,endpoint_error,gamma_error,const_error))
    _,base=solve(alpha,512)
    perturbation=.01*np.sin(np.arange(513)*.13)
    perturbation[0]=0.
    _,perturbed=solve(alpha,512,input_values=1.+perturbation)
    stability_ratio=A0*np.max(abs(perturbed-base))/np.max(abs(perturbation))
    check(f'discrete_stability_bound_{alpha}',max(0.,stability_ratio-1),1e-12)
    stability_rows.append((alpha,float(stability_ratio)))
save_csv('convergence.csv',list(conv[0]),[list(d.values()) for d in conv])
save_csv('endpoints.csv',['alpha','endpoint_identity_error','constant_gamma_relative_error','constant_window_error'],endpoints)
save_csv('trace_counterexample.csv',['alpha','kappa','numerical_ratio_at_T','limiting_ratio'],counter)
save_csv('stability.csv',['alpha','normalized_stability_ratio'],stability_rows)
table('tab:convergence',r'Full-history GL solution errors for $a_0=1.3$, $a_1=0.7$, $T=4$. $E_s$ is the full-grid error for the smooth manufactured solution $y=t^2$. $E_w$ is the full-grid error for the unit-step solution $y=(1-E_\alpha(-a_0t^\alpha/a_1))/a_0$, and $E_\delta$ is its error on $[0.25,4]$. Rates are $p=\log_2(E_N/E_{2N})$; the first row has no rate.',
      [r'$\alpha$',r'$N$',r'$E_s$',r'$p_s$',r'$E_w$',r'$p_w$',r'$E_\delta$',r'$p_\delta$'],
      [[dec(d['alpha']),d['n'],sci(d['smooth_error']),dec(d['smooth_rate']),sci(d['step_error']),dec(d['step_rate']),sci(d['window_error']),dec(d['window_rate'])] for d in conv])
table('tab:endpoints',r'Endpoint and constant-response checks at $N=4096$. The endpoint error compares $\mathcal G_h^\alpha(f-f(0))$ with $\mathcal G_h^\alpha f-f(0)c_{\alpha,n}^h$ for $f=1+t^2$. The constant window is $[0.25,4]$. The final column is a separate stability test at $N=512$, using $\rho_n=0.01\sin(0.13n)$; its theoretical upper bound is one.',
      [r'$\alpha$',r'Endpoint error',r'Gamma rel. error',r'Constant error',r'$a_0\|e\|_\infty/\|\rho\|_\infty$'],[[dec(a),sci(e),sci(g),sci(c),dec(next(row[1] for row in stability_rows if row[0]==a))] for a,e,g,c in endpoints])
table('tab:trace-counterexample',r'Nonzero-inner-trace counterexample at $T=4$, $N=4096$. For $f=t^\beta/\Gamma(\beta+1)$, the exact inner signal is $g=1$. Entries are the ratio of the discrete outer blend to $\RLD^{\alpha+\beta}f(T)$; their continuum limits are $1-\kappa$, not a common value of one. The calculation uses the exact inner signal to isolate the outer-trace effect.',
      [r'$\alpha$',r'$\kappa=0$',r'$\kappa=0.5$',r'$\kappa=1$'],[[dec(a)]+[f'{next(row[2] for row in counter if row[0]==a and row[1]==k):.7f}' for k in (0.,.5,1.)] for a in ALPHAS])
for n in NS:
    row=[T/n]
    for alpha in ALPHAS:
        d=next(d for d in conv if d['alpha']==alpha and d['n']==n)
        row += [d['smooth_error'],d['step_error'],d['window_error']]
    plot_conv.append(row)
columns=['h']+[f'{v}{i}' for i in range(3) for v in ['smooth','step','window']]
save_csv('plot_convergence.csv',columns,plot_conv)
styles=['blue!70!black,mark=*','red!75!black,mark=square*','black,mark=triangle*']
figure('smooth_convergence','plot_convergence.csv','h',[(f'smooth{i}',rf'$\alpha={a:g}$',styles[i]) for i,a in enumerate(ALPHAS)],r'Step size $h$',r'Maximum error',r'Smooth manufactured-solution convergence. All errors include the initial grid interval; the input is evaluated from the continuous equation.', 'fig:smooth-convergence',True,True)
curves=[]
for i,a in enumerate(ALPHAS):
    curves += [(f'step{i}',rf'$\alpha={a:g}$, full',styles[i]),(f'window{i}',rf'$\alpha={a:g}$, window',styles[i]+',dashed,mark options={solid}')]
figure('startup_convergence','plot_convergence.csv','h',curves,r'Step size $h$',r'Maximum error',r'Unit-step convergence with weak startup singularity. Solid curves use the full grid; dashed curves use the fixed physical window $[0.25,4]$. The smooth-data theorem does not prescribe a rate for this problem.','fig:startup-convergence',True,True,extra='legend columns=2')

print('3/6: harmonic tail quadrature',flush=True)
ts=np.geomspace(8,512,65); harmonics=[]; harmonic_table=[]
for i,a in enumerate(ALPHAS):
    out=np.array([harmonic(a,t) for t in ts])
    fine=np.array([harmonic(a,t,32,256) for t in ts])
    check(f'harmonic_quadrature_refinement_{a}',np.max(abs(fine-out)),2e-9)
    main=(1j)**a*np.exp(1j*ts)
    raw=abs(fine-main); corrected=abs(fine-main+ts**(-a)/math.gamma(1-a))
    raw_rate=-np.polyfit(np.log(ts[-20:]),np.log(raw[-20:]),1)[0]
    corrected_rate=-np.polyfit(np.log(ts[-20:]),np.log(corrected[-20:]),1)[0]
    harmonic_table.append((a,raw_rate,corrected_rate,float(np.max(abs(fine-out)))))
    harmonics += [raw,corrected]
save_csv('harmonic.csv',['t']+[f'{v}{i}' for i in range(3) for v in ['raw','corrected']],zip(ts,*harmonics))
table('tab:harmonic',r'Harmonic-tail diagnostics at $\omega=1$. Decay exponents are least-squares slopes over the final 20 points of a 65-point logarithmic grid on $[8,512]$. The theoretical exponents are $\alpha$ before correction and $\alpha+1$ after correction. The final column records independent quadrature refinement.',
      [r'$\alpha$',r'Raw exponent',r'Corrected exponent',r'Quadrature change'],[[dec(a),dec(r),dec(c),sci(q)] for a,r,c,q in harmonic_table])
curves=[]
for i,a in enumerate(ALPHAS):
    curves += [(f'raw{i}',rf'$\alpha={a:g}$, raw',styles[i]+',mark=none'),(f'corrected{i}',rf'$\alpha={a:g}$, corrected',styles[i]+',dashed,mark=none')]
figure('harmonic_tail','harmonic.csv','t',curves,r'Time $t$',r'Absolute harmonic error',r'Independent integral evaluation of the terminal-zero sinusoidal derivative. Dashed curves subtract the explicit leading terminal-memory term; no GL approximation is used in this figure.','fig:harmonic-tail',True,True,extra='legend columns=2')

print('4/6: independent anchored identification and frequency fit',flush=True)
alpha=.6; nt=8192
train_times=np.arange(.25,2.00001,.0625)
valid_times=np.arange(2.25,4.00001,.0625)
def response(t):
    e=ml_relax(alpha,A0/A1,t,512)
    return (1-e)/A0+KTRUE*ANCHOR*e
train_true=response(train_times); valid_true=response(valid_times)
check('ML_half_order_reference',max(abs(float(ml_relax(.5,1.,np.array([t]),256)[0])-math.exp(t)*math.erfc(math.sqrt(t))) for t in (.05,.5,2.)),2e-11)
refine=[]; models={}
for n in (*NS,nt):
    t,z=solve(alpha,n,0.,ANCHOR,0.)
    _,one=solve(alpha,n,1.,ANCHOR,ANCHOR)
    v=one-z; h=T/n
    ti=np.rint(train_times/h).astype(int); vi=np.rint(valid_times/h).astype(int)
    check(f'fixed_observation_grid_{n}',max(np.max(abs(t[ti]-train_times)),np.max(abs(t[vi]-valid_times))),1e-14)
    khat=float(np.clip(np.dot(v[ti],train_true-z[ti])/np.dot(v[ti],v[ti]),0,1))
    refine.append((n,khat,abs(khat-KTRUE),rmse(z[ti]+khat*v[ti],train_true),rmse(z[vi]+khat*v[vi],valid_true)))
    if n==nt: models=dict(t=t,z=z,v=v,ti=ti,vi=vi)
save_csv('anchor_refinement.csv',['N','kappa_hat','absolute_parameter_error','train_RMSE','validation_RMSE'],refine)
table('tab:anchor-refinement',r'Noiseless anchored identification using independent continuous-reference observations, $\alpha=0.6$, $r=0.8$, and $\kappa_{\rm true}=0.65$. Training uses 29 fixed times on $[0.25,2]$ and validation uses 29 times on $[2.25,4]$. Circuit parameters are known in this table; $y_0=\kappa r$ for every candidate.',
      [r'$N$',r'$\widehat\kappa$',r'$|\widehat\kappa-\kappa_{\rm true}|$',r'Training RMSE',r'Validation RMSE'],[[n,f'{k:.7f}',sci(e),sci(tr),sci(va)] for n,k,e,tr,va in refine])
rng_freq=np.random.default_rng(SEED)
omega=np.geomspace(.1,100,60)
H=frequency_model((A0,A1,alpha),omega)
Hobs=H+abs(H)*.005*(rng_freq.normal(size=60)+1j*rng_freq.normal(size=60))/math.sqrt(2)
fitted,fit_records=fit_frequency(Hobs,omega)
exact_fit,exact_records=fit_frequency(H,omega)
check('frequency_noiseless_parameter_recovery',np.max(abs(exact_fit-np.array([A0,A1,alpha]))),1e-8)
save_csv('frequency.csv',['omega','real_observed','imag_observed','magnitude_observed','magnitude_exact','magnitude_fitted','phase_observed','phase_fitted'],zip(omega,Hobs.real,Hobs.imag,abs(Hobs),abs(H),abs(frequency_model(fitted,omega)),np.angle(Hobs),np.angle(frequency_model(fitted,omega))))
table('tab:frequency-fit',r'Synthetic complex-frequency fit with 60 logarithmically spaced frequencies on $[0.1,100]$ and relative complex noise scale $0.005$. Positive coefficients are fitted in logarithmic coordinates; $0.05\leq\alpha\leq0.95$. Three fixed initializations use the same weighted complex least-squares objective.',
      ['Parameter','True value','Fitted value'],[[r'$a_0$',f'{A0:.6f}',f'{fitted[0]:.6f}'],[r'$a_1$',f'{A1:.6f}',f'{fitted[1]:.6f}'],[r'$\alpha$',f'{alpha:.6f}',f'{fitted[2]:.6f}']],align='lrr')
figure('frequency_fit','frequency.csv','omega',[('magnitude_exact','Exact model','black,mark=none'),('magnitude_observed','Synthetic data','blue!70!black,only marks,mark=o'),('magnitude_fitted','Fitted model','red!75!black,dashed,mark=none')],r'Angular frequency $\omega$',r'$|H(i\omega)|$',r'Synthetic complex-response fit. The plotted magnitude is one diagnostic; both real and imaginary components enter the objective.','fig:frequency-fit',True,True)

# End-to-end fit: freeze the frequency estimates before fitting a single transient coefficient.
rng_trans=np.random.default_rng(SEED+1)
train_obs=train_true+rng_trans.normal(0,SIGMA,len(train_times))
valid_obs=valid_true+rng_trans.normal(0,SIGMA,len(valid_times))
ap0,ap1,apalpha=fitted
t,pz=solve_parameters(apalpha,ap0,ap1,nt)
_,po=solve_parameters(apalpha,ap0,ap1,nt,1.,ANCHOR)
pv=po-pz; ti=models['ti']; vi=models['vi']
kfit=float(np.clip(np.dot(pv[ti],train_obs-pz[ti])/np.dot(pv[ti],pv[ti]),0,1))
_,direct=solve_parameters(apalpha,ap0,ap1,nt,.37,ANCHOR)
check('anchored_affine_response',np.max(abs(direct-(pz+.37*pv))),5e-11)
z=models['z']; v=models['v']
_,g0=solve(alpha,256,0.,0.,0.)
_,g1=solve(alpha,256,1.,0.,0.)
check('genuine_zero_trace_independence',np.max(abs(g0-g1)),1e-14)
grid=np.linspace(0,1,101)
res0=pz[ti]-train_obs
analytic=(np.dot(res0,res0)+2*grid*np.dot(res0,pv[ti])+grid**2*np.dot(pv[ti],pv[ti]))/len(ti)
direct_profile=np.array([np.mean((pz[ti]+k*pv[ti]-train_obs)**2) for k in grid])
check('quadratic_profile_identity',np.max(abs(analytic-direct_profile)),2e-13)
save_csv('profile.csv',['kappa','training_MSE','continuous_noiseless_MSE'],zip(grid,direct_profile,[np.mean((response(train_times)+(k-KTRUE)*ANCHOR*ml_relax(alpha,A0/A1,train_times,512)-train_true)**2) for k in grid]))
rows=[]
for label,k in [('Anchored endpoint 0',0.),('Fitted anchored model',kfit),('Anchored endpoint 1',1.)]:
    pred=pz+k*pv
    rows.append((label,k,rmse(pred[ti],train_obs),rmse(pred[vi],valid_obs),rmse(pred[vi],valid_true)))
save_csv('pipeline_errors.csv',['model','kappa','training_RMSE','validation_RMSE_observed','validation_RMSE_exact'],rows)
table('tab:pipeline',r'One synthetic frequency--transient pipeline at $N=8192$. Frequency-fitted coefficients are frozen before fitting $\kappa$ on the training data; validation times are disjoint. Transient noise has standard deviation $0.005$. Errors in the exact-validation column use the noise-free reference and are available only because this is a synthetic experiment. Endpoints refer to the anchored family.',
      ['Model',r'$\kappa$',r'Train RMSE',r'Validation RMSE',r'Exact validation'],[[label,f'{k:.6f}',sci(tr),sci(va),sci(ex)] for label,k,tr,va,ex in rows],align='lrrrr')
select=np.arange(0,nt+1,64)
exact_plot=response(t[select])
save_csv('anchor_curves.csv',['t','reference','endpoint0','fitted','endpoint1'],zip(t[select],exact_plot,pz[select],(pz+kfit*pv)[select],po[select]))
save_csv('transient_observations.csv',['split','t','exact','observed'],[('training',tt,yy,zz) for tt,yy,zz in zip(train_times,train_true,train_obs)]+[('validation',tt,yy,zz) for tt,yy,zz in zip(valid_times,valid_true,valid_obs)])
figure('anchor_transient','anchor_curves.csv','t',[('reference','Continuous reference','black,mark=none'),('endpoint0',r'Anchored $\kappa=0$','blue!70!black,dashed,mark=none'),('fitted',r'Fitted initial state','red!75!black,dashed,mark=o,mark repeat=12'),('endpoint1',r'Anchored $\kappa=1$','gray!70!black,densely dotted,mark=none')],r'Time $t$',r'Output $y$',r'Synthetic responses using the frozen frequency estimates. The fitted normalized initial state uses only the training interval. Each candidate is a Caputo solution with $y_0=\kappa r$; the reference and fitted curves nearly coincide.','fig:anchor-transient',extra='legend columns=2')
figure('quadratic_profile','profile.csv','kappa',[('training_MSE','Discrete training loss','blue!70!black,mark=none'),('continuous_noiseless_MSE','Continuous noiseless loss','red!75!black,dashed,mark=none')],r'Normalized initial state $\kappa$',r'Mean squared error',r'Initial-state least-squares profiles in the anchored representation. The discrete curve uses frequency-fitted parameters and noisy observations; the continuous curve uses true parameters and noiseless observations. Differences include discretization, parameter-fit and observation errors.','fig:quadratic-profile',extra='xmin=0,xmax=1,ymin=0,scaled y ticks=false,yticklabel style={/pgf/number format/fixed,/pgf/number format/precision=3}')

print('5/6: conditional synthetic repeated-noise assessment',flush=True)
rng_mc=np.random.default_rng(SEED+2)
train_noise=rng_mc.normal(0,SIGMA,(REPLICATES,len(ti)))
valid_noise=rng_mc.normal(0,SIGMA,(REPLICATES,len(vi)))
mc_obs=train_true+train_noise; mc_val=valid_true+valid_noise
khats=np.clip(((mc_obs-z[ti])@v[ti])/np.dot(v[ti],v[ti]),0,1)
pred=z[vi]+khats[:,None]*v[vi]
fit_rmse=np.sqrt(np.mean((pred-mc_val)**2,axis=1))
end0_rmse=np.sqrt(np.mean((z[vi]-mc_val)**2,axis=1))
end1_rmse=np.sqrt(np.mean((z[vi]+v[vi]-mc_val)**2,axis=1))
save_csv('monte_carlo.csv',['replicate','kappa_hat','validation_RMSE_fitted','validation_RMSE_endpoint0','validation_RMSE_endpoint1'],zip(range(REPLICATES),khats,fit_rmse,end0_rmse,end1_rmse))
mc_statistics=[]
for label,values in [(r'$\widehat\kappa$',khats),(r'Fitted validation RMSE',fit_rmse),(r'Endpoint 0 minus fitted RMSE',end0_rmse-fit_rmse),(r'Endpoint 1 minus fitted RMSE',end1_rmse-fit_rmse)]:
    lo,hi=np.quantile(values,[.025,.975])
    mc_statistics.append(dict(quantity=label,mean=float(np.mean(values)),sd=float(np.std(values,ddof=1)),q025=float(lo),q975=float(hi)))
table('tab:monte-carlo',r'Conditional repeated-noise assessment: 400 independent synthetic training/validation noise draws, with the true circuit parameters and anchor held known, at $N=8192$. Quantiles describe this repeated-simulation distribution; they are not confidence intervals derived from measured data and exclude uncertainty in the circuit parameters and anchor.',
      ['Quantity','Mean','SD',r'2.5\% quantile',r'97.5\% quantile'],[[d['quantity'],f"{d['mean']:.6f}",f"{d['sd']:.6f}",f"{d['q025']:.6f}",f"{d['q975']:.6f}"] for d in mc_statistics],align='lrrrr')

print('6/6: export and provenance',flush=True)
(ROOT/'results_table.tex').write_text('% Generated by run_stage3.py; synthetic results only.\n'+'\n'.join(tables),encoding='utf-8')
outputs.append(ROOT/'results_table.tex')
summary=dict(seed=SEED,alphas=list(ALPHAS),grid_sizes=list(NS),a0=A0,a1=A1,T=T,delta=DELTA,
    identification=dict(alpha=alpha,anchor=ANCHOR,kappa_true=KTRUE,finest_N=nt,training_times=train_times.tolist(),validation_times=valid_times.tolist(),noise_sigma=SIGMA,replicates=REPLICATES,frequency_parameters=fitted.tolist(),frequency_fits=fit_records,kappa_pipeline=kfit,refinement=refine,monte_carlo=mc_statistics),
    convergence=conv,harmonic_diagnostics=harmonic_table,checks=checks,all_checks_passed=all(c['passed'] for c in checks),
    runtime_seconds=time.perf_counter()-start,python=platform.python_version(),numpy=np.__version__,
    reference_method='Positive spectral integral; inverse-CDF transform; 512/1024-point Gauss-Legendre refinement; no GL data generation.',
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),stability=stability_rows,
    output_hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in outputs})
(DATA/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(dict(all_checks_passed=summary['all_checks_passed'],checks=len(checks),seconds=summary['runtime_seconds'],pipeline_parameters=fitted.tolist(),kappa_pipeline=kfit,last_convergence=[d for d in conv if d['n']==NS[-1]],harmonic=harmonic_table),indent=2),flush=True)
if not summary['all_checks_passed']: raise SystemExit(1)
