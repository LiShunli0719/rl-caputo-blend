"""One entry point for all 16 tables and 8 figures. Never edits a manuscript."""
from pathlib import Path
import subprocess,sys,json,hashlib,argparse,time

ROOT=Path(__file__).resolve().parent

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--no-plots',action='store_true',help='Compute and verify all numbers without importing Matplotlib')
    args=parser.parse_args(); start=time.perf_counter()
    commands=[ROOT/'run_identification.py',ROOT/'experiments/coverage_extension/run_all.py']
    for path in commands: subprocess.run([sys.executable,str(path)],cwd=ROOT,check=True)
    table=ROOT/'results_table.tex'
    for path in [ROOT/'experiments/coverage_extension/sinusoidal/table.tex',ROOT/'experiments/coverage_extension/boundaries/tables.tex']:
        with table.open('a',encoding='utf-8') as f: f.write('\n'+path.read_text(encoding='utf-8'))
    # The combined table now has all 16 items; update its recorded checksum.
    summary_path=ROOT/'results/summary.json'
    summary=json.loads(summary_path.read_text(encoding='utf-8'))
    summary['output_hashes']['results_table.tex']=hashlib.sha256(table.read_bytes()).hexdigest()
    summary['complete_experiments']={'tables':16,'figures':8,'extensions':'experiments/coverage_extension','plots_generated':not args.no_plots}
    summary_path.write_text(json.dumps(summary,indent=2),encoding='utf-8')
    if not args.no_plots: subprocess.run([sys.executable,str(ROOT/'plot_results.py')],cwd=ROOT,check=True)
    subprocess.run([sys.executable,str(ROOT/'verify_results.py')],cwd=ROOT,check=True)
    print(f'Full reproduction completed in {time.perf_counter()-start:.2f} seconds.',flush=True)

if __name__=='__main__': main()
