"""Final-review entry point: reproduce base cases and additional identifiability tests."""
from pathlib import Path
import runpy, json, math, hashlib, csv, time
import numpy as np

R=Path(__file__).resolve().parent
base=runpy.run_path(str(R/'run_basic.py'))
save=base['save_csv']; ml=base['ml_relax']; fit=base['fit_frequency']
freq=base['frequency_model']; solver=base['solve_parameters']
table=base['table']; checks=[]
def check(name,error,tol):checks.append(dict(name=name,error=float(error),tolerance=tol,passed=bool(error<=tol)))
start=time.perf_counter(); rng=np.random.default_rng(20261120)
a0=1.3; a1=.7; r=.8; true_k=.65; sigma=.005
early=np.arange(.25,2.00001,.0625); late=np.arange(2.25,4.00001,.0625)
stress=[]
for alpha in (.3,.6,.85):
    e=ml(alpha,a0/a1,early); v=r*e; z=(1-e)/a0
    for truth in (.2,.65,.9):
        for noise in (0.,.005,.02):
            yy=z+truth*v+rng.normal(0,noise,(200,len(early)))
            estimates=np.clip(((yy-z)@v)/np.dot(v,v),0,1)
            stress.append(dict(alpha=alpha,true_kappa=truth,sigma=noise,mean=float(estimates.mean()),
                sd=float(estimates.std(ddof=1)),bias=float(estimates.mean()-truth),
                parameter_RMSE=float(np.sqrt(np.mean((estimates-truth)**2))),
                boundary_fraction=float(np.mean((estimates==0)|(estimates==1))),
                predicted_unconstrained_sd=float(noise/np.linalg.norm(v))))
            if noise==0:check(f'noiseless_state_recovery_{alpha}_{truth}',np.max(abs(estimates-truth)),1e-12)
save('review_stress_grid.csv',list(stress[0]),[list(row.values()) for row in stress])

window=[]
for name,t in [('early',early),('late',late)]:
    v=r*ml(.6,a0/a1,t)
    window.append((name,float(np.linalg.norm(v)),float(sigma/np.linalg.norm(v))))
save('review_windows.csv',['window','sensitivity_norm','predicted_iid_sd'],window)
correlation=[]
v=r*ml(.6,a0/a1,early)
for rho in (0.,.8):
    noise=rng.normal(0,sigma,(1000,len(early)))
    for j in range(1,len(early)):noise[:,j]=rho*noise[:,j-1]+math.sqrt(1-rho*rho)*noise[:,j]
    est=true_k+(noise@v)/np.dot(v,v)
    covariance=sigma*sigma*rho**abs(np.arange(len(v))[:,None]-np.arange(len(v))[None,:])
    predicted=float(np.sqrt(v@covariance@v)/np.dot(v,v))
    correlation.append((rho,float(est.mean()),float(est.std(ddof=1)),predicted))
save('review_correlated_noise.csv',['rho','mean_kappa','empirical_sd','predicted_sd'],correlation)
anchor_rows=[]
for ratio in (.9,1.,1.1):
    assumed=r*ratio; true_e=ml(.6,a0/a1,early)
    yy=(1-true_e)/a0+true_k*r*true_e; zz=(1-true_e)/a0; vv=assumed*true_e
    estimate=float(np.dot(vv,yy-zz)/np.dot(vv,vv))
    anchor_rows.append((ratio,estimate,true_k/ratio,abs(estimate-true_k),float(np.max(abs(zz+estimate*vv-yy)))))
    check(f'anchor_confounding_{ratio}',abs(estimate-true_k/ratio),1e-12)
save('review_anchor_bias.csv',['assumed_to_true_anchor','estimated_kappa','exact_reparameterized_kappa','absolute_coefficient_bias','output_discrepancy'],anchor_rows)

# Repeated full pipeline, re-estimating all frequency parameters on every draw.
omega=np.geomspace(.1,100,60); exact_H=freq((a0,a1,.6),omega)
etr=ml(.6,a0/a1,early); eva=ml(.6,a0/a1,late)
ytr=(1-etr)/a0+true_k*r*etr; yva=(1-eva)/a0+true_k*r*eva
N=4096; h=4/N; ti=np.rint(early/h).astype(int); vi=np.rint(late/h).astype(int)
pipeline=[]; failures=[]
print('Final-review repeated full pipeline: 200 runs',flush=True)
for rep in range(200):
    try:
        Hobs=exact_H+abs(exact_H)*.005*(rng.normal(size=60)+1j*rng.normal(size=60))/math.sqrt(2)
        theta,records=fit(Hobs,omega)
        _,z=solver(theta[2],theta[0],theta[1],N)
        _,one=solver(theta[2],theta[0],theta[1],N,1.,r)
        vv=one-z
        obs_tr=ytr+rng.normal(0,sigma,len(early)); obs_va=yva+rng.normal(0,sigma,len(late))
        khat=float(np.clip(np.dot(vv[ti],obs_tr-z[ti])/np.dot(vv[ti],vv[ti]),0,1))
        prediction=z[vi]+khat*vv[vi]
        pipeline.append((rep,*map(float,theta),khat,float(np.sqrt(np.mean((prediction-obs_va)**2))),float(np.sqrt(np.mean((prediction-yva)**2))),min(q['loss'] for q in records),int(khat in (0.,1.))))
    except (ValueError,ArithmeticError,np.linalg.LinAlgError) as exc:
        failures.append(dict(replicate=rep,error=str(exc)))
    if (rep+1)%50==0:print('Completed',rep+1,'runs',flush=True)
save('review_full_pipeline.csv',['replicate','a0_hat','a1_hat','alpha_hat','kappa_hat','validation_RMSE','exact_validation_RMSE','frequency_loss','boundary'],pipeline)
check('full_pipeline_failed_runs',len(failures),0)
pipe=np.array(pipeline)
stats=[]
for name,column in [('a0',1),('a1',2),('alpha',3),('kappa',4),('validation_RMSE',5),('exact_validation_RMSE',6)]:
    x=pipe[:,column]; lo,hi=np.quantile(x,[.025,.975])
    stats.append(dict(quantity=name,mean=float(x.mean()),sd=float(x.std(ddof=1)),q025=float(lo),q975=float(hi)))

# Start a separate generated-table buffer, then append its contents to results_table.tex.
base['tables'].clear()
summary_rows=[]
for alpha in (.3,.6,.85):
    for noise in (0.,.005,.02):
        rows=[d for d in stress if d['alpha']==alpha and d['sigma']==noise]
        summary_rows.append([f'{alpha:g}',f'{noise:g}',base['sci'](max(abs(d['bias']) for d in rows)),base['sci'](max(d['sd'] for d in rows)),base['sci'](max(d['parameter_RMSE'] for d in rows)),f"{max(d['boundary_fraction'] for d in rows):.3f}"])
table('tab:review-stress',r'Additional continuous-reference initial-state tests: three true coefficients $\kappa\in\{0.2,0.65,0.9\}$ per row, 200 independent noise draws per coefficient, known circuit parameters and $r=0.8$. Entries are maxima across the three coefficients. This test isolates observation-noise sensitivity; it does not add GL discretization error.',
      [r'$\alpha$',r'$\sigma$',r'Max. $|$bias$|$',r'Max. SD',r'Max. parameter RMSE',r'Boundary fraction'],summary_rows)
table('tab:review-pipeline',r'Repeated full frequency--transient pipeline: 200 independent runs, $N=4096$, with circuit parameters re-estimated from noisy complex frequency data on every run. The anchor is known. Quantiles describe the repeated-simulation distribution, not experimental confidence intervals.',
      ['Quantity','Mean','SD',r'2.5\% quantile',r'97.5\% quantile'],[[d['quantity'].replace('_',r'\_')]+[f"{d[k]:.6f}" for k in ['mean','sd','q025','q975']] for d in stats],align='lrrrr')
table('tab:review-anchor',r'Noiseless anchor-miscalibration diagnostic with $\kappa_{\rm true}=0.65$. The same output can be reproduced after a biased anchor calibration by changing the coefficient inversely. A small output residual does not establish correct coefficient recovery.',
      [r'$r_{\rm assumed}/r_{\rm true}$',r'$\widehat\kappa$',r'$|\widehat\kappa-0.65|$',r'Max. output discrepancy'],[[f'{x:.2f}',f'{k:.6f}',f'{err:.6f}',base['sci'](out)] for x,k,target,err,out in anchor_rows])
text='\n'.join(base['tables'])
with (R/'results_table.tex').open('a',encoding='utf-8') as f:f.write('\n% Additional final-review experiments.\n'+text)

caputo_data=base['weights'](.6,2048)
tt,yy=solver(.6,a0,a1,2048,.37,r)
c=(4/2048)**(-.6)*np.cumsum(caputo_data)
gl=np.convolve(caputo_data,yy)[:len(yy)]*(4/2048)**(-.6)
cap=np.convolve(caputo_data,yy-yy[0])[:len(yy)]*(4/2048)**(-.6)
check('anchored_equals_Caputo_discrete',np.max(abs(gl-.37*r*c-cap)),1e-11)

result=dict(seed=20261120,stress_cases=len(stress),stress_replicates_per_case=200,pipeline_runs=200,pipeline_N=N,
    pipeline_successes=len(pipeline),pipeline_failures=failures,pipeline_boundary_fits=int(pipe[:,8].sum()),
    pipeline_statistics=stats,windows=window,correlated_noise=correlation,anchor_bias=anchor_rows,
    checks=checks,all_checks_passed=all(d['passed'] for d in checks),runtime_seconds=time.perf_counter()-start,
    source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
# Refresh base provenance to cover the final table and regenerated figures.
s=json.loads((R/'results/summary.json').read_text(encoding='utf-8'))
s['output_hashes']={p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in s['output_hashes']}
s['final_review_extension']='results/review_summary.json; generated by run_final_experiments.py'
(R/'results/summary.json').write_text(json.dumps(s,ensure_ascii=False,indent=2),encoding='utf-8')
result['output_hashes']={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'results').glob('review_*.csv')}
(R/'results/review_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False,indent=2),flush=True)
if not result['all_checks_passed']:raise SystemExit(1)
