"""Verify numeric outputs, paper-reference agreement, tables and plot layout."""
from pathlib import Path
import ast,csv,hashlib,json,math,subprocess,sys
import numpy as np

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'experiments/coverage_extension'))
from common import gauss,weights,relax

def main():
    checks=[]
    def check(name,error,tol=0):
        error=float(error); checks.append({'name':name,'error':error,'tolerance':tol,'passed':bool(np.isfinite(error) and error<=tol)})
    for p in ROOT.rglob('*.py'):
        ast.parse(p.read_text(encoding='utf-8'),filename=str(p))
    check('all_python_files_parse',0)
    for name in ['summary.json','review_summary.json']:
        s=json.loads((ROOT/'results'/name).read_text(encoding='utf-8'))
        check(name+'_internal_failures',sum(not c['passed'] for c in s['checks']))
        for path,h in s['output_hashes'].items(): check('hash_'+path,int(hashlib.sha256((ROOT/path).read_bytes()).hexdigest()!=h))
    subprocess.run([sys.executable,str(ROOT/'experiments/coverage_extension/verify.py')],check=True,cwd=ROOT)
    extra=json.loads((ROOT/'experiments/coverage_extension/validation.json').read_text(encoding='utf-8'))
    check('extension_independent_verification',sum(not c['passed'] for c in extra['checks']))
    for n in [1,2,24,192]:
        x,w=gauss(n); degree=min(2*n-1,12)
        check(f'quadrature_mass_{n}',abs(w.sum()-1),2e-13)
        check(f'quadrature_moment_{n}',abs(w@x**degree-1/(degree+1)),2e-13)
    for a in [.3,.6,.85]:
        e=relax(a,1.3/.7,np.linspace(0,4,101),512)
        check(f'relaxation_bounds_{a}',max(0,-e.min(),e.max()-1),2e-13)
        check(f'relaxation_monotonicity_{a}',max(0,np.diff(e).max()),2e-13)
        d=np.genfromtxt(ROOT/f'results/time_step_a{a:g}.csv',delimiter=',',names=True)
        h=d['t'][1]-d['t'][0]; y=d['smooth_GL']; w=weights(a,len(y)-1)
        forcing=.7*2*d['t']**(2-a)/math.gamma(3-a)+1.3*d['t']**2
        derivative=np.convolve(w,y)[:len(y)]*h**(-a)
        check(f'smooth_GL_residual_{a}',np.max(abs(.7*derivative[1:]+1.3*y[1:]-forcing[1:])),2e-9)
    table=(ROOT/'results_table.tex').read_text(encoding='utf-8')
    check('sixteen_tables',abs(table.count(r'\begin{table}')-16))
    check('caption_fragment_removed',int('Errors compare the genuine blended GL derivative' in table))
    check('readable_table11_labels',int('Noise-free validation RMSE' not in table))
    for t in json.loads((ROOT/'table_templates.json').read_text(encoding='utf-8')):
        check('caption_'+t['label'],int(t['caption'] not in table))
    reference=ROOT/'reference/paper'; compared=[]; discrepancies=[]
    for old in sorted(reference.rglob('*.csv')):
        relative=old.relative_to(reference); new=ROOT/relative; check('reference_file_'+str(relative),int(not new.exists()))
        if not new.exists(): continue
        with old.open(encoding='utf-8-sig',newline='') as f: expected=list(csv.reader(f))
        with new.open(encoding='utf-8-sig',newline='') as f: actual=list(csv.reader(f))
        check('reference_header_'+str(relative),int(expected[0]!=actual[0]))
        check('reference_rows_'+str(relative),abs(len(expected)-len(actual)))
        if len(expected)!=len(actual): continue
        worst=0.; strings=0
        for er,ar in zip(expected[1:],actual[1:]):
            if len(er)!=len(ar): strings+=1; continue
            for ev,av in zip(er,ar):
                if not ev or not av:
                    strings+=int(ev!=av); continue
                try:
                    x,y=float(ev),float(av)
                    if np.isnan(x) or np.isnan(y): strings+=int(not(np.isnan(x) and np.isnan(y)))
                    elif not np.isfinite(x) or not np.isfinite(y): strings+=int(x!=y)
                    else: worst=max(worst,abs(x-y)/max(1.,abs(x)))
                except ValueError: strings+=int(ev!=av)
        check('reference_labels_missing_'+str(relative),strings)
        # Same generator and algorithms: allow last-bit BLAS/platform changes.
        check('reference_values_'+str(relative),worst,2e-8)
        compared.append(str(relative)); discrepancies.append(worst)
    check('all_56_paper_CSV_compared',abs(len(compared)-56))
    summary=json.loads((ROOT/'results/summary.json').read_text(encoding='utf-8'))
    if summary['complete_experiments']['plots_generated']:
        geometry=json.loads((ROOT/'figures/geometry_validation.json').read_text(encoding='utf-8'))
        check('plot_geometry',int(not geometry['all_passed']))
        for name in ['defect_spectrum','smooth_convergence','startup_convergence','harmonic_tail','frequency_fit','anchor_transient','quadratic_profile','sinusoidal_response']:
            for ext in ['pdf','png','svg']: check('figure_'+name+'.'+ext,int(not (ROOT/'figures'/(name+'.'+ext)).exists()))
    report={'all_passed':all(c['passed'] for c in checks),'checks':checks,'reference_csv_compared':len(compared),'maximum_scaled_numeric_difference':max(discrepancies,default=0),'extension_numeric_checks':len(extra['checks']),'plots_checked':summary['complete_experiments']['plots_generated']}
    (ROOT/'results/validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print('Verification:',sum(c['passed'] for c in checks),'/',len(checks),'passed; max reference discrepancy:',report['maximum_scaled_numeric_difference'],flush=True)
    if not report['all_passed']: raise RuntimeError([c for c in checks if not c['passed']])

if __name__=='__main__': main()
