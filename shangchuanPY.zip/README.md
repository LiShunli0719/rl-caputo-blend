# Terminal Traces in an RL–Caputo Blend — Python experiments

Companion code for **Terminal Traces in an RL–Caputo Blend: Composition and Limits of Parameter Identification**, by Ling Wang, Shunli Li and Mingjun Bai. The manuscript is a submission draft; this package has no assigned publication DOI or repository URL.

## Run all experiments

Tested environment: Python 3.12, NumPy 2.3.5 and Matplotlib 3.10.7. Install the requirements in your own Python environment:

```text
python -m pip install -r requirements.txt
python run_experiments.py
```

The entry point resolves paths relative to itself and works even when launched from a different working directory. It runs all original experiments plus the sinusoidal and boundary branches, exports **16 LaTeX tables and 8 figures**, and runs independent numeric checks and comparison against the archived paper data. No MATLAB, TeX installation, manuscript source, proprietary toolbox or network service is needed for computation.

To compute all numbers without Matplotlib or figure export:

```text
python run_experiments.py --no-plots
```

This option still runs the full experiment counts and numeric verification. For a numeric-only environment, install `numpy==2.3.5`; Matplotlib is used only by `plot_results.py`.

After a complete run, figures can be redrawn and computed results checked independently:

```text
python plot_results.py
python verify_results.py
```

Run the complete entry again to restore all 16 tables after using a smaller component entry. All runs overwrite generated results, figures and `results_table.tex`, but do not overwrite `reference/paper/`.

The upload archive contains the programs and the original paper reference data. Regenerable CSV results, figures and table fragments are omitted to avoid storing the same data twice. Run `python run_experiments.py` once before using the plotting or numerical-verification commands separately.

## Directory contents

| Path | Role |
|---|---|
| `run_experiments.py` | Complete numerical/plotting/verification entry |
| `run_identification.py` | Original base and identification experiments; calls `run_basic.py` |
| `run_basic.py` | Nine base tables and the original numerical calculations |
| `experiments/coverage_extension/run_all.py` | Runs both deterministic extensions |
| `experiments/coverage_extension/sinusoidal/run.py` | Three frequencies, zero/nonzero states and short-record GL checks |
| `experiments/coverage_extension/boundaries/run.py` | Regularity, extreme orders, anchor degeneracy and positive-coefficient boundaries |
| `experiments/coverage_extension/common.py` | Spectral quadratures, GL recurrence and export utilities |
| `table_format.py`, `table_templates.json` | Current manuscript captions, headings and mathematical display labels |
| `plot_results.py` | Eight figures as vector PDF/SVG and 600 dpi PNG, without TeX |
| `verify_results.py` | Checks hashes, residuals, quadrature, tables, all 56 archived CSV files and figure geometry |
| `experiments/coverage_extension/verify.py` | Independent recomputation of extension metrics from saved time series |
| `results/` | Created by the first run: base/identification CSV data and JSON settings/checks |
| `experiments/coverage_extension/{sinusoidal,boundaries}/` | Branch programs; output CSV, LaTeX and JSON files are created by the first run |
| `reference/paper/` | Original paper CSV files and consolidated experiment settings in provenance.json |
| `results_table.tex` | Created by the first run: all 16 generated tables |
| `experiment_map.csv`, `data_dictionary.csv` | Paper-item/code/output map and CSV field inventory |
| `VALIDATION.md`, `release_validation.json` | Actual full-run release evidence |
| `MANIFEST.json`, `verify_manifest.py` | SHA-256 release inventory and integrity checker |
| `CITATION.cff` | Citation metadata without an invented DOI or repository URL |

PGFPlots `.tex` fragments are generated as editable alternatives to the static figures. The Python run uses the CSV data directly.

## Reproduction and numerical interpretation

The algorithms, parameters and NumPy PCG64 random streams are the same as the original paper calculations. The entry points separate the base calculations (`run_basic.py`), identification experiments (`run_identification.py`) and complete workflow (`run_experiments.py`). Captions and display labels follow the manuscript.

Defaults include 400 conditional noise draws, 27 stress settings with 200 draws each, 1000 draws in each correlated-noise design, and 200 complete frequency/transient fits. Seeds are 20261117–20261120. Deterministic quadratures, three-frequency/two-state sinusoidal cases and every boundary experiment are fully run. Current settings are in the source and output JSON files.

The release validator compares **every archived paper CSV** with freshly computed output, checking headers, row counts, textual labels, missing-value locations and numerical values within a scaled tolerance of `2e-8`. This tolerance accommodates platform-dependent floating-point fitting and BLAS differences; it is not a claim of universal bytewise equality. In the validated environment, the actual largest discrepancy is reported in `results/validation.json`.

Python and MATLAB use different random generators. This Python package uses the paper's NumPy PCG64 implementation and can be compared directly with the original paper simulations; the companion MATLAB package uses twister and does not reproduce repeated-noise draws digit for digit.

All variables are nondimensional. The experiments use analytical benchmarks and synthetic observations generated from the specified models and noise distributions. The anchored scalar family is a Caputo initial-value family with `q=kappa*r`; the coefficient is interpreted relative to a known anchor. Unknown anchors give product ambiguity. The sinusoidal long-window calculation is spectral time-domain convolution, with separate GL marching checks. The 2% crossing is a numerical envelope diagnostic, not a real-device specification. Boundary examples do not enlarge the proved theorem domains.

## Integrity, citation and license

After extraction, run `python verify_manifest.py` to check the distributed source and reference files. Generated outputs are not part of the input-file manifest; check them with `python verify_results.py` after the first full run.

Citation metadata are provided in `CITATION.cff`. Add the DOI and repository URL when available. A software and data license remains to be selected by the authors.
