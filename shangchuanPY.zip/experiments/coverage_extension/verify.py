"""Recompute new-table metrics, raw waveform fits and manuscript dependencies."""
from pathlib import Path
import sys,re,hashlib,json,csv
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common import *
ROOT=Path(__file__).resolve().parent;PAPER=ROOT.parents[1]
checks,check=checker()
def data(branch,name):return np.genfromtxt(ROOT/branch/name,delimiter=',',names=True,dtype=None,encoding='utf-8')
for branch in ['sinusoidal','boundaries']:
    s=json.loads((ROOT/branch/'summary.json').read_text())
    check(branch+'_internal_checks',sum(not x['passed'] for x in s['checks']),0)
    for name,h in s['output_hashes'].items():check(branch+'_hash_'+name,int(hashlib.sha256((ROOT/branch/name).read_bytes()).hexdigest()!=h),0)
metrics=data('sinusoidal','metrics.csv')
for row in metrics:
    w=row['omega'];q=row['q'];d=data('sinusoidal',f'late_w{w:g}_q{q:g}.csv')
    H=1/(1.3+.7*(1j*w)**.6);J=np.column_stack([np.cos(w*d['t']),np.sin(w*d['t'])])
    c=np.linalg.lstsq(J,d['output'],rcond=None)[0];h=c[0]-1j*c[1]
    check(f'gain_{w}_{q}',abs(abs(h)-row['measured_gain']),1e-13)
    check(f'phase_{w}_{q}',abs(np.angle(h)*180/np.pi-row['measured_phase_deg']),1e-10)
    check(f'target_{w}_{q}',max(abs(d['steady_prediction']-np.real(H*np.exp(1j*w*d['t'])))),1e-13)
    check(f'input_{w}_{q}',max(abs(d['input']-np.cos(w*d['t']))),1e-13)
    e=max(abs(d['output']-d['steady_prediction']))/abs(H)
    check(f'raw_error_{w}_{q}',abs(e-row['raw_rel_error']),1e-12)
    # Stored early marching data must satisfy the discrete Caputo equation.
    d=data('sinusoidal',f'gl_w{w:g}_q{q:g}.csv');dt=d['t'][1]-d['t'][0];y=d['GL_output'];a=.6
    cap=np.convolve(weights(a,len(y)-1),y-y[0])[:len(y)]*dt**(-a)
    check(f'GL_residual_{w}_{q}',max(abs(.7*cap[1:]+1.3*y[1:]-d['input'][1:])),2e-10)
    check(f'GL_trace_{w}_{q}',abs(y[0]-q),0)

regularity=data('boundaries','regularity.csv')
for name in np.unique(regularity['case']):
    rows=regularity[regularity['case']==name]
    for kind in ['full','window']:
        errors=rows[kind+'_derivative_error'];rate=np.log2(errors[:-1]/errors[1:])
        check(f'boundary_rates_{name}_{kind}',max(abs(rate-rows[kind+'_rate'][1:])),1e-12)
    d=data('boundaries',name+'.csv');e=abs(d['GL_derivative']-d['exact_derivative'])
    check('saved_full_error_'+name,abs(max(e)-rows['full_derivative_error'][-1]),1e-13)
    check('saved_window_error_'+name,abs(max(e[d['t']>=.25])-rows['window_derivative_error'][-1]),1e-13)

report=dict(all_passed=all(x['passed'] for x in checks),checks=checks)
(ROOT/'validation.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print('Extension verification:',sum(x['passed'] for x in checks),'/',len(checks),'passed')
if not report['all_passed']:raise RuntimeError([x for x in checks if not x['passed']])
