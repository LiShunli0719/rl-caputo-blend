"""Direct time-domain sinusoidal convolution, not synthetic H(iw) samples."""
from pathlib import Path
import sys,math
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from common import *
R=Path(__file__).resolve().parent
checks,check=checker();a=.6;a0=1.3;a1=.7;lam=a0/a1

def response(t,omega,q,n=1024):
    # Numerically integrate the positive diffusive realization of the causal
    # Volterra convolution. Each real exponential mode is integrated exactly
    # against exp(i*omega*t); the target transfer formula is NOT used here.
    t=np.asarray(t);u,w=spectrum(a,lam,n);out=np.empty(t.shape,dtype=complex)
    coeff=u/(u+1j*omega)
    for k in range(0,t.size,256):
        tt=t.ravel()[k:k+256]; decay=np.exp(-tt[:,None]*u)
        modes=(np.exp(1j*omega*tt)[:,None]-decay)*coeff
        out.ravel()[k:k+256]=modes@w/a0+q*(decay@w)
    return out

def bound(t,omega,q,n=1024):
    u,w=spectrum(a,lam,n)
    return np.exp(-t*u)@(w*(abs(q)+u/(a0*np.abs(u+1j*omega))))

rows=[];details=[];envelopes=[];wave=[];glrows=[]
for omega in [.1,1.,100.]:
    H=1/(a0+a1*(1j*omega)**a); P=2*np.pi/omega
    for q in [0.,.52]:
        # A predeclared 2% bound criterion; no detrending of the simulated output.
        lo=0.;hi=1.
        while bound(hi,omega,q)>.02*abs(H) and hi<1e7:hi*=2
        reached=bound(hi,omega,q)<=.02*abs(H)
        if reached:
            for _ in range(60):
                mid=(lo+hi)/2
                if bound(mid,omega,q)>.02*abs(H):lo=mid
                else:hi=mid
        settle=hi;T=math.ceil(max(8*P,2*settle,8.)/P)*P
        t=T-4*P+np.arange(1024)*P/256
        out=response(t,omega,q);fine=response(t,omega,q,512)
        target=np.real(H*np.exp(1j*omega*t));y=out.real
        design=np.column_stack([np.cos(omega*t),np.sin(omega*t)])
        coeff=np.linalg.lstsq(design,y,rcond=None)[0];Hfit=coeff[0]-1j*coeff[1]
        ae=abs(abs(Hfit)/abs(H)-1);pe=abs(np.angle(Hfit/H))*180/np.pi
        raw=max(abs(y-target))/abs(H);qd=max(abs(out-fine))/abs(H)
        check(f'quadrature_{omega}_{q}',qd,2e-7)
        check(f'amplitude_{omega}_{q}',ae,.002)
        check(f'phase_{omega}_{q}',pe,.2)
        check(f'uncorrected_waveform_{omega}_{q}',raw,.02)
        check(f'settling_reached_{omega}_{q}',int(not reached),0)
        csvout(R,f'late_w{omega:g}_q{q:g}.csv',['t','input','output','steady_prediction'],zip(t,np.cos(omega*t),y,target))
        earlyT=16*P;previous=None;errors=[]
        for n in [1024,2048,4096]:
            tg=np.linspace(0,earlyT,n+1)
            _,yg=solve(a,a0,a1,earlyT,n,q,np.cos(omega*tg))
            ref=response(tg,omega,q).real;mask=tg>=12*P
            err=np.sqrt(np.mean((yg[mask]-ref[mask])**2))/abs(H)
            errors.append(err);glrows.append((omega,q,n,earlyT/n,err))
            if n==4096:csvout(R,f'gl_w{omega:g}_q{q:g}.csv',['t','input','GL_output','convolution_reference'],zip(tg,np.cos(omega*tg),yg,ref))
        check(f'GL_refinement_{omega}_{q}',errors[-1]/errors[0],.5)
        rows.append((omega,q,abs(H),np.angle(H)*180/np.pi,settle,T,abs(Hfit),np.angle(Hfit)*180/np.pi,ae,pe,raw,qd,errors[-1]))
        details.append(dict(omega=omega,q=q,settling_2percent=settle,T=T,amplitude_relative_error=ae,phase_error_degrees=pe,raw_relative_error=raw,quadrature_relative_change=qd,GL_errors=errors))
        tt=np.geomspace(.01,max(8192,T),150)
        vals=np.array([bound(x,omega,q)/abs(H) for x in tt])
        # Save actual complex time-response discrepancy as well as its envelope.
        actual=abs(response(tt,omega,q)-H*np.exp(1j*omega*tt))/abs(H)
        check(f'bound_{omega}_{q}',max(np.maximum(actual-vals,0)),2e-8)
        envelopes.append((tt,vals,actual))
        if omega==100:wave.append((t,y,target))

csvout(R,'metrics.csv',['omega','q','predicted_gain','predicted_phase_deg','settling_2percent','T','measured_gain','measured_phase_deg','gain_rel_error','phase_error_deg','raw_rel_error','quadrature_rel_change','GL_window_rel_RMSE'],rows)
csvout(R,'gl_refinement.csv',['omega','q','N','h','relative_window_RMSE'],glrows)
# Common physical time grid for a fair comparison of the settling envelopes.
tt=np.geomspace(.01,8192,180);cols=[tt];heads=['t']
for omega in [.1,1.,100.]:
    for q in [0.,.52]:
        H=1/(a0+a1*(1j*omega)**a);cols.append(np.array([bound(x,omega,q)/abs(H) for x in tt]));heads.append(f'e{len(cols)-2}')
csvout(R,'envelopes.csv',heads,zip(*cols))
for i,(t,y,pred) in enumerate(wave):
    # Different settling horizons are displayed against phase within the last cycles.
    csvout(R,f'wave_q{i}.csv',['cycles','output','steady'],zip((t-t[0])*100/(2*np.pi),y,pred))
tab=table('tab:direct-sine',r'Direct system time-domain cosine experiment, $a_0=1.3$, $a_1=0.7$, $\alpha=0.6$. $q=y(0)=\kappa r$. $t_{2\%}$ is the spectral-envelope crossing defined in the text, not a certified physical settling time. Gain and phase are fitted on the last four periods without detrending; $E_g$ is relative gain error, $E_\phi$ is phase error in degrees and $E_y$ is maximum relative waveform discrepancy. $E_{\rm GL}$ is a separate last-four-period relative RMSE at $N=4096$ over 16 periods.',
    [r'$\omega$',r'$q$',r'$t_{2\%}$',r'$E_g$',r'$E_\phi$',r'$E_y$',r'$E_{\rm GL}$'],
    [[f'{w:g}',f'{q:g}',f'{ts:.2f}',sci(ae),sci(pe),sci(raw),sci(gl)] for w,q,g,p,ts,T,gf,pf,ae,pe,raw,qd,gl in rows])
(R/'table.tex').write_text(tab,encoding='utf-8')
prefix='experiments/coverage_extension/sinusoidal/'
f=[r'\begin{figure}[htbp]',r'\centering',r'\begin{tikzpicture}',r'\begin{axis}[journalaxis,height=5cm,xmode=log,ymode=log,xlabel={Time $t$},ylabel={Relative transient envelope},legend columns=2]']
styles=['blue!70!black','red!75!black','black']
for i,w in enumerate([.1,1,100]):
    for j,q in enumerate([0,.52]):
        f += [rf'\addplot+[{styles[i]},mark=none'+(',dashed' if j else '')+rf'] table[x=t,y=e{2*i+j},col sep=comma]{{{prefix}envelopes.csv}};',rf'\addlegendentry{{$\omega={w:g},q={q:g}$}}']
f += [r'\end{axis}',r'\end{tikzpicture}',r'\par\vspace{8mm}',r'\begin{tikzpicture}',r'\begin{axis}[journalaxis,height=5cm,xlabel={Periods from start of late window},ylabel={Output $y$},legend columns=2]']
for i in [0,1]:
    f += [rf'\addplot+[{styles[i]},mark=none'+(',dashed' if i else '')+rf'] table[x=cycles,y=output,col sep=comma]{{{prefix}wave_q{i}.csv}};',rf'\addlegendentry{{$q={0 if i==0 else .52}$}}']
f += [rf'\addplot+[black,densely dotted,mark=none] table[x=cycles,y=steady,col sep=comma]{{{prefix}wave_q1.csv}};',r'\addlegendentry{Predicted steady response}',r'\end{axis}',r'\end{tikzpicture}',r'\caption{Direct sinusoidal system verification. Top: normalized spectral envelopes for the six time-domain responses; the nonzero initial-state contribution delays settling. Bottom: late waveforms at $\omega=100$, each using its own reported observation horizon. These nearly coincident traces are numerical convolution responses and the predicted steady waveform; no terminal trend is removed.}\label{fig:direct-sine}',r'\end{figure}']
(R/'figure.tex').write_text('\n'.join(f)+'\n',encoding='utf-8')
finish(R,dict(alpha=a,a0=a0,a1=a1,frequencies=[.1,1,100],initial_states=[0,.52],input='cos(omega*t)',details=details,reference='1024-node positive diffusive convolution; exact forced exponential modes; 512-node refinement'),checks)
print(json.dumps(details,indent=2))
