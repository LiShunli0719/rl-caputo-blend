"""Run the two independent experiment branches without changing the paper."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
for branch in ['sinusoidal','boundaries']:
    subprocess.run([sys.executable,str(root/branch/'run.py')],check=True)
print('Both numeric experiment branches completed. The root run_experiments.py combines all tables, draws all figures and verifies the outputs.')
