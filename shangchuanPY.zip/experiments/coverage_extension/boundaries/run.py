"""Boundary coverage: distinguish hypotheses from excluded limiting cases."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from common import *
R=Path(__file__).resolve().parent;checks,check=checker()
grids=[256,512,1024,2048,4096];regularity=[];final=[];solution_rows=[]
cases=[('smooth-low',.02,2.,0.,0.),('smooth-high',.98,2.,0.,0.),
    ('ramp',.6,1.,0.,0.),('AC-power',.6,.25,0.,0.),('nonzero-trace',.6,2.,1.,.37)]
for name,a,p,constant,k in cases:
    previous=None
    for n in grids:
        h=4/n;t=np.arange(n+1)*h;w=weights(a,n);f=constant+t**p
        approx=np.convolve(w,f)[:n+1]*h**(-a)-k*constant*np.cumsum(w)*h**(-a)
        exact=np.zeros(n+1);tt=t[1:]
        exact[1:]=math.gamma(p+1)/math.gamma(p+1-a)*tt**(p-a)+(1-k)*constant*tt**(-a)/math.gamma(1-a)
        errors=abs(approx[1:]-exact[1:]);window=t[1:]>=.25
        full=max(errors);win=max(errors[window]);rates=[None,None] if previous is None else list(np.log2(np.array(previous)/[full,win]))
        regularity.append((name,a,p,constant,k,n,h,full,rates[0],win,rates[1]));previous=[full,win]
        if n==4096:
            csvout(R,name+'.csv',['t','function','GL_derivative','exact_derivative'],zip(t[1:],f[1:],approx[1:],exact[1:]))
            final.append((name,a,full,rates[0],win,rates[1]))
    if name.startswith('smooth'):
        check(name+'_derivative_first_order',abs(rates[0]-1),.01)
        # Also test an equation solution, distinct from derivative consistency.
        for n in grids:
            h=4/n;t=np.arange(n+1)*h
            forcing=.7*2*t**(2-a)/math.gamma(3-a)+1.3*t*t
            _,y=solve(a,1.3,.7,4,n,0,forcing)
            error=max(abs(y-t*t));solution_rows.append((a,n,error))
        check(name+'_solution_first_order',abs(np.log2(solution_rows[-2][2]/solution_rows[-1][2])-1),.01)
    elif name=='ramp':check(name+'_predicted_first_step_order',abs(rates[0]-(1-a)),1e-8)
    elif name=='AC-power':check(name+'_predicted_first_step_order',abs(rates[0]-(p-a)),1e-8)
    else:check(name+'_window_first_order',abs(rates[1]-1),.02)
    if name!='AC-power':check(name+'_window_consistency',abs(rates[1]-1),.02)
csvout(R,'regularity.csv',['case','alpha','power','constant','kappa','N','h','full_derivative_error','full_rate','window_derivative_error','window_rate'],regularity)
csvout(R,'extreme_order_solution.csv',['alpha','N','solution_max_error'],solution_rows)

# Sensitivity degeneracy: r=0, kappa=0 with nonzero r, tiny r, negative r.
tobs=np.arange(.25,2.00001,.0625);e=relax(.6,1.3/.7,tobs);z=(1-e)/1.3
anchorrows=[];epsnorm=1e-4;epsvec=epsnorm*e/np.linalg.norm(e)
for r,k in [(0.,.65),(.8,0.),(1e-6,.65),(-.8,.65)]:
    v=r*e;norm=np.linalg.norm(v);y=z+k*v
    if norm==0:
        recovery=None;noise_amplification=None
        check('zero_anchor_invariance',max(abs(y-z)),0)
    else:
        recovery=v@(y-z)/(v@v)
        perturbed=v@(y+epsvec-z)/(v@v)
        noise_amplification=abs(perturbed-recovery)
        check(f'anchor_noiseless_recovery_{r}_{k}',abs(recovery-k),1e-8)
        check(f'sensitivity_bound_attained_{r}_{k}',abs(noise_amplification-epsnorm/norm),1e-8)
    anchorrows.append((r,k,k*r,norm,recovery,noise_amplification))
    csvout(R,f'anchor_r{r:g}_k{k:g}.csv',['t','zero_state','sensitivity','output','additive_perturbation'],zip(tobs,z,v,y,epsvec))
q=.52
for r,k in [(.8,.65),(1.,.52),(.65,.8)]:
    check(f'product_invariance_{r}',max(abs(z+k*r*e-z-q*e)),1e-14)
csvout(R,'anchor_degeneracy.csv',['r','kappa','q','sensitivity_norm','noiseless_unconstrained_estimate','perturbed_coefficient_change'],anchorrows)

# Nonzero inner trace: deliberately violates exactly one composition hypothesis.
a=.6;b=.6;k=.37;n=4096;h=4/n;w=weights(a,n)
outer=(1-k)*np.cumsum(w)[-1]*h**(-a);exact=4**(-a)/math.gamma(1-a)
inner_ratio=outer/exact;check('nonzero_inner_trace_limit',abs(inner_ratio-(1-k)),5e-5)
csvout(R,'inner_trace.csv',['alpha','beta','kappa','inner_trace','ratio_at_T','predicted_limit'],[(a,b,k,1.,inner_ratio,1-k)])

# Positive-coefficient boundary: theorem is not uniform as a0 tends to zero.
stability=[]
for a0,a1 in [(.01,.7),(1.3,.01)]:
    n=1024;rho=.01*np.sin(np.arange(n+1)*.13);rho[0]=0
    _,base=solve(.6,a0,a1,4,n);_,perturbed=solve(.6,a0,a1,4,n,0,1+rho)
    ratio=a0*max(abs(perturbed-base))/max(abs(rho))
    check(f'positive_coefficient_stability_{a0}_{a1}',max(0,ratio-1),1e-12)
    stability.append((a0,a1,ratio,1/a0))
    csvout(R,f'stability_a0{a0:g}_a1{a1:g}.csv',['t','forcing_perturbation','base','perturbed'],zip(np.linspace(0,4,n+1),rho,base,perturbed))
csvout(R,'coefficient_boundary.csv',['a0','a1','normalized_gain','theoretical_gain_bound'],stability)

# Check extreme-order reference quadrature before using it to describe sensitivity.
quad=[]
for a in [.02,.98]:
    times=np.r_[0.,np.geomspace(1e-3,4,80)];lo=relax(a,1.3/.7,times,512);hi=relax(a,1.3/.7,times,1024);fine=relax(a,1.3/.7,times,2048)
    initial_change=max(abs(lo-hi));change=max(abs(hi-fine));quad.append((a,initial_change,change));check(f'extreme_order_reference_{a}',change,1e-8)
csvout(R,'reference_refinement.csv',['alpha','absolute_512_1024_change','absolute_1024_2048_change'],quad)
tex=table('tab:boundary-regularity',r'Regularity and order-boundary tests for the derivative approximation at $N=4096$, $T=4$. Errors compare the genuine blended GL derivative with its gamma-function value; these are derivative errors, not the solution errors of Table~\ref{tab:convergence}. The fixed window is $[0.25,4]$. $p$ denotes the last mesh-refinement rate; negative full-grid rates indicate growing error near zero. For the nonzero-trace case $f=1+t^2$, $\kappa=0.37$; other cases have zero trace.',
    ['Case',r'$\alpha$',r'$E_{\rm full}$',r'$p_{\rm full}$',r'$E_\delta$',r'$p_\delta$'],
    [[name,f'{a:g}',sci(full),f'{p:.3f}',sci(win),f'{pw:.3f}'] for name,a,full,p,win,pw in final],align='lrrrrr')
tex+=table('tab:boundary-anchor',r'Anchor-boundary diagnostics with known circuit parameters. The perturbation has Euclidean norm $10^{-4}$ and is aligned with the relaxation vector. $\Delta\kappa_{\rm u}$ concerns the unconstrained estimate; projection would conceal large sensitivity by clipping. A zero true initial state with known nonzero $r$ remains identifiable, whereas $r=0$ removes sensitivity. Negative anchors are permitted by the stated theorem.',
    [r'$r$',r'$\kappa$',r'$q$',r'$\|v\|_2$',r'$\widehat\kappa_{\rm u}$',r'$|\Delta\kappa_{\rm u}|$'],
    [[sci(r),f'{k:g}',sci(q),sci(norm),'--' if kh is None else f'{kh:.6f}','--' if dk is None else sci(dk)] for r,k,q,norm,kh,dk in anchorrows])
tex+=table('tab:boundary-coefficients',r'Positive-coefficient boundary stability tests at $\alpha=0.6$, $N=1024$, using the same sinusoidal forcing perturbation as Table~\ref{tab:endpoints}. The normalized gain remains below one; the unnormalized theoretical bound $1/a_0$ deteriorates as $a_0$ approaches zero. The cases $a_0=0$ or $a_1=0$ are outside the proposition and are not simulated as if covered.',
    [r'$a_0$',r'$a_1$',r'$a_0\|e\|_\infty/\|\rho\|_\infty$',r'$1/a_0$'],
    [[f'{a0:g}',f'{a1:g}',f'{rr:.6f}',f'{bound:g}'] for a0,a1,rr,bound in stability])
(R/'tables.tex').write_text(tex,encoding='utf-8')
finish(R,dict(regularity_finest=final,anchors=anchorrows,inner_trace_ratio=inner_ratio,coefficient_tests=stability,quadrature=quad,
    excluded_cases=['alpha=0 or 1: not defined as members of the blended family','nonzero inner trace: excluded from conditional composition','C2 compatibility failure: no uniform full-grid first-order claim','r=0: no anchored identifiability','a0=0 or a1=0: not covered by positive coefficient proposition']),checks)
print(json.dumps(dict(regularity=final,anchors=anchorrows,stability=stability,quadrature=quad),indent=2))
