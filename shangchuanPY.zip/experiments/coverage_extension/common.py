"""Shared numerical/export utilities; Python 3 + NumPy only."""
from pathlib import Path
from functools import lru_cache
import csv, json, math, hashlib
import numpy as np
from numpy.polynomial.legendre import leggauss

@lru_cache(None)
def gauss(n):
    x,w=leggauss(n); return (x+1)/2,w/2

def spectrum(alpha,lam,n):
    v,w=gauss(n)
    logu=(math.log(lam)+np.log(np.sin(np.pi*alpha*v))-np.log(np.sin(np.pi*alpha*(1-v))))/alpha
    return np.exp(np.minimum(logu,700)),w

def relax(alpha,lam,t,n=1024):
    u,w=spectrum(alpha,lam,n); t=np.asarray(t); flat=t.ravel(); out=np.empty(len(flat))
    for k in range(0,len(flat),256):out[k:k+256]=np.exp(-flat[k:k+256,None]*u)@w
    return out.reshape(t.shape)

def weights(alpha,n):
    w=np.ones(n+1)
    for j in range(1,n+1):w[j]=w[j-1]*(1-(alpha+1)/j)
    return w

def solve(alpha,a0,a1,T,n,q=0.,input_values=None):
    h=T/n;t=np.arange(n+1)*h;w=weights(alpha,n);c=np.cumsum(w)*h**(-alpha)
    x=np.ones(n+1) if input_values is None else np.asarray(input_values)
    y=np.zeros(n+1);y[0]=q; f=a1*h**(-alpha)
    for k in range(1,n+1):y[k]=(x[k]+a1*q*c[k]-f*(w[1:k+1]@y[k-1::-1]))/(a0+f)
    return t,y

def csvout(root,name,heads,rows):
    root.mkdir(parents=True,exist_ok=True)
    with (root/name).open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(heads);writer.writerows(rows)

def table(label,caption,heads,rows,align=None):
    import sys
    sys.path.insert(0,str(Path(__file__).resolve().parents[2]))
    from table_format import current_table
    caption,heads,rows=current_table(label,caption,heads,rows)
    lines=[r'\begin{table}[htbp]',r'\centering\small',r'\setlength{\tabcolsep}{5pt}',
        rf'\caption{{{caption}}}\label{{{label}}}',rf'\begin{{tabular}}{{{align or "r"*len(heads)}}}',
        r'\toprule',' & '.join(heads)+r' \\',r'\midrule']
    lines+=[' & '.join(map(str,row))+r' \\' for row in rows]
    return '\n'.join(lines+[r'\bottomrule',r'\end{tabular}',r'\end{table}',''])

def sci(x):
    if x==0:return '$0$'
    a,e=f'{x:.2e}'.split('e');return rf'${a}\times10^{{{int(e)}}}$'

def finish(root,summary,checks):
    summary['checks']=checks;summary['all_passed']=all(x['passed'] for x in checks)
    summary['output_hashes']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.iterdir()) if p.suffix in ['.csv','.tex']}
    (root/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(root.name,summary['all_passed'],len(checks),'checks',flush=True)
    if not summary['all_passed']:raise RuntimeError([x for x in checks if not x['passed']])

def checker():
    checks=[]
    def check(name,error,tol):
        checks.append(dict(name=name,error=float(error),tolerance=tol,passed=bool(np.isfinite(error) and error<=tol)))
    return checks,check
