"""Draw all eight paper figures directly from the generated CSV files."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent; OUT=ROOT/'figures'; OUT.mkdir(exist_ok=True)
COLORS=['#0040a6','#bf1f1f','#222222']
plt.rcParams.update({'font.family':'STIXGeneral','mathtext.fontset':'stix','font.size':11,
                     'axes.labelsize':12,'axes.linewidth':.8,'lines.linewidth':1.4,
                     'lines.markersize':4,'legend.fontsize':10,'pdf.fonttype':42,'svg.fonttype':'none'})

def data(name): return np.genfromtxt(ROOT/name,delimiter=',',names=True,encoding='utf-8')

def axes():
    fig=plt.figure(figsize=(17/2.54,12/2.54)); ax=fig.add_axes([.17,.15,.78,.62]); return fig,ax

def decorate(ax,xlabel,ylabel):
    ax.set_xlabel(xlabel); ax.set_ylabel(ylabel); ax.grid(True,alpha=.15)
    ax.tick_params(direction='in',top=True,right=True)

geometry=[]
def legend(fig,ax,anchor):
    lg=ax.legend(loc='lower center',bbox_to_anchor=anchor,bbox_transform=fig.transFigure,ncols=2,frameon=False)
    fig.canvas.draw(); renderer=fig.canvas.get_renderer(); a=ax.get_window_extent(renderer); b=lg.get_window_extent(renderer)
    assert not a.overlaps(b),'Legend overlaps the plotting axes'
    assert b.x0>=0 and b.y0>=0 and b.x1<=fig.bbox.width and b.y1<=fig.bbox.height,'Legend outside canvas'
    geometry.append({'figure':len(geometry)+1,'axes_bounds':list(a.bounds),'legend_bounds':list(b.bounds),'legend_outside_axes':True})

def save(fig,name):
    for extension in ['pdf','png','svg']:
        fig.savefig(OUT/(name+'.'+extension),dpi=600,facecolor='white')
    plt.close(fig)

def main():
    fig,ax=axes(); omega=np.arange(0,11,2); columns=[omega]
    for i,(a,b) in enumerate([(.6,.7),(.8,.6),(.9,.8)]):
        import math
        y=omega*.001**(1-a-b)/math.gamma(2-a-b); columns.append(y)
        ax.plot(omega,y,'-o',color=COLORS[i],label=rf'$(\alpha,\beta)=({a:g},{b:g})$')
    np.savetxt(ROOT/'results/defect_spectrum.csv',np.column_stack(columns),delimiter=',',header='omega,pair1,pair2,pair3',comments='')
    decorate(ax,r'Angular frequency $|\omega|$','Composition defect'); legend(fig,ax,(.56,.79)); save(fig,'defect_spectrum')
    d=data('results/plot_convergence.csv')
    for name,startup in [('smooth_convergence',False),('startup_convergence',True)]:
        fig,ax=axes()
        for i,a in enumerate([.3,.6,.85]):
            column=('step' if startup else 'smooth')+str(i)
            ax.loglog(d['h'],d[column],'-o',color=COLORS[i],label=rf'$\alpha={a:g}$'+(', full' if startup else ''))
            if startup: ax.loglog(d['h'],d['window'+str(i)],'--s',color=COLORS[i],label=rf'$\alpha={a:g}$, window')
        decorate(ax,r'Step size $h$','Maximum error'); legend(fig,ax,(.56,.79)); save(fig,name)
    fig,ax=axes(); d=data('results/harmonic.csv')
    for i,a in enumerate([.3,.6,.85]):
        ax.loglog(d['t'],d['raw'+str(i)],color=COLORS[i],label=rf'$\alpha={a:g}$, raw')
        ax.loglog(d['t'],d['corrected'+str(i)],'--',color=COLORS[i],label=rf'$\alpha={a:g}$, corrected')
    decorate(ax,r'Time $t$','Absolute harmonic error'); legend(fig,ax,(.56,.79)); save(fig,'harmonic_tail')
    fig,ax=axes(); d=data('results/frequency.csv')
    ax.loglog(d['omega'],d['magnitude_exact'],'k-',label='Exact model')
    ax.loglog(d['omega'],d['magnitude_observed'],'o',color=COLORS[0],fillstyle='none',label='Synthetic data')
    ax.loglog(d['omega'],d['magnitude_fitted'],'--',color=COLORS[1],label='Fitted model')
    decorate(ax,r'Angular frequency $\omega$',r'$|H(i\omega)|$'); legend(fig,ax,(.56,.79)); save(fig,'frequency_fit')
    fig,ax=axes(); d=data('results/anchor_curves.csv')
    ax.plot(d['t'],d['reference'],'k-',label='Continuous reference')
    ax.plot(d['t'],d['endpoint0'],'--',color=COLORS[0],label=r'Anchored $\kappa=0$')
    ax.plot(d['t'],d['fitted'],'--o',markevery=12,color=COLORS[1],label='Fitted initial state')
    ax.plot(d['t'],d['endpoint1'],':',color='#666666',label=r'Anchored $\kappa=1$')
    decorate(ax,r'Time $t$',r'Output $y$'); legend(fig,ax,(.56,.79)); save(fig,'anchor_transient')
    fig,ax=axes(); d=data('results/profile.csv')
    ax.plot(d['kappa'],d['training_MSE'],color=COLORS[0],label='Discrete training loss')
    ax.plot(d['kappa'],d['continuous_noiseless_MSE'],'--',color=COLORS[1],label='Continuous noiseless loss')
    ax.set_xlim(0,1); ax.set_ylim(0,1.05*max(d['training_MSE'].max(),d['continuous_noiseless_MSE'].max()))
    decorate(ax,r'Normalized initial state $\kappa$','Mean squared error'); legend(fig,ax,(.56,.79)); save(fig,'quadratic_profile')
    fig=plt.figure(figsize=(17/2.54,21/2.54)); top=fig.add_axes([.17,.57,.78,.27]); bottom=fig.add_axes([.17,.10,.78,.27])
    prefix='experiments/coverage_extension/sinusoidal/'; d=data(prefix+'envelopes.csv')
    for i,w in enumerate([.1,1,100]):
        for j,q in enumerate([0,.52]): top.loglog(d['t'],d['e'+str(2*i+j)],'--' if j else '-',color=COLORS[i],label=rf'$\omega={w:g},q={q:g}$')
    decorate(top,r'Time $t$','Relative transient envelope'); legend(fig,top,(.56,.865))
    for j,q in enumerate([0,.52]):
        d=data(prefix+f'wave_q{j}.csv'); bottom.plot(d['cycles'],d['output'],'--' if j else '-',color=COLORS[j],label=rf'$q={q:g}$')
    bottom.plot(d['cycles'],d['steady'],':k',label='Predicted steady response')
    decorate(bottom,'Periods from start of late window',r'Output $y$'); legend(fig,bottom,(.56,.395)); save(fig,'sinusoidal_response')
    (OUT/'geometry_validation.json').write_text(json.dumps({'all_passed':True,'axes_and_legends':geometry},indent=2),encoding='utf-8')
    print('Eight figures exported as PDF, PNG (600 dpi) and SVG; all legends outside axes.')

if __name__=='__main__': main()
