"""Current manuscript captions and display labels, without changing numbers."""
from pathlib import Path
import json

TEMPLATES={x['label']:x for x in json.loads((Path(__file__).parent/'table_templates.json').read_text(encoding='utf-8'))}

def current_table(label,caption,heads,rows):
    item=TEMPLATES[label]
    rows=[list(row) for row in rows]
    if label=='tab:review-pipeline':
        names={'a0':r'$a_0$','a1':r'$a_1$','alpha':r'$\alpha$','kappa':r'$\kappa$',
               r'validation\_RMSE':'Validation RMSE',r'exact\_validation\_RMSE':'Noise-free validation RMSE'}
        for row in rows: row[0]=names.get(row[0],row[0])
    return item['caption'],item['heads'],rows
